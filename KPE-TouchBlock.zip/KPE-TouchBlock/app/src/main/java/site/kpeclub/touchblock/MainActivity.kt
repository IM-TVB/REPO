package site.kpeclub.touchblock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Surface
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val bg = 0xFF0D0D0D.toInt()
    private val card = 0xFF161B22.toInt()
    private val blue = 0xFF3B82F6.toInt()
    private val teal = 0xFF14B8A6.toInt()
    private val muted = 0xFF9CA3AF.toInt()

    private lateinit var status: TextView
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(BlockService.PREFS, MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        applyPadding()

        root.addView(label("KPE TouchBlock", 26f, Color.WHITE, true))
        root.addView(label("Blocks touches on the broken left edge.", 14f, muted))
        root.addView(space(20))

        status = label("", 15f, muted).apply {
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(card)
                cornerRadius = dp(12).toFloat()
            }
        }
        root.addView(status)
        root.addView(space(14))

        val open = Button(this).apply {
            text = "Turn on in Accessibility"
            transformationMethod = null
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(blue, teal)
            ).apply { cornerRadius = dp(12).toFloat() }
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(open)
        root.addView(space(24))

        val enabled = Switch(this).apply {
            text = "Block left edge"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("enabled", true)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("enabled", on).apply()
                BlockService.refresh()
            }
        }
        root.addView(enabled)
        root.addView(space(16))

        val guide = Switch(this).apply {
            text = "Show red guide"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("guide", true)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("guide", on).apply()
                BlockService.refresh()
            }
        }
        root.addView(guide)
        root.addView(space(24))

        val startWidth = prefs.getInt("width", 30)
        val widthLabel = label("Width: $startWidth dp", 15f, Color.WHITE)
        root.addView(widthLabel)
        root.addView(space(8))

        val seek = SeekBar(this).apply {
            max = 110
            progress = startWidth - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    val w = p + 10
                    widthLabel.text = "Width: $w dp"
                    prefs.edit().putInt("width", w).apply()
                    BlockService.refresh()
                    applyPadding()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        root.addView(seek)
        root.addView(space(24))

        root.addView(
            label(
                "Tip: use 3-button navigation. The back swipe from the left edge is blocked too.",
                13f, muted
            )
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })
    }

    // Keep the app UI away from the blocked edge, on whichever side it is now
    @Suppress("DEPRECATION")
    private fun applyPadding() {
        val width = getSharedPreferences(BlockService.PREFS, MODE_PRIVATE).getInt("width", 30)
        val strip = dp(width + 20)
        var l = dp(20)
        var t = dp(40)
        var r = dp(20)
        var b = dp(24)
        when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> b = maxOf(b, strip)
            Surface.ROTATION_180 -> r = strip
            Surface.ROTATION_270 -> t = maxOf(t, strip)
            else -> l = strip
        }
        root.setPadding(l, t, r, b)
    }

    override fun onResume() {
        super.onResume()
        val on = BlockService.instance != null
        status.text = if (on) "●  Service is ON" else "●  Service is OFF"
        status.setTextColor(if (on) teal else 0xFFF87171.toInt())
    }
}
