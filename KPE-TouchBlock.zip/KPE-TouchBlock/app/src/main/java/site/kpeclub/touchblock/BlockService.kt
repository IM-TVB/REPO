package site.kpeclub.touchblock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Draws a thin invisible window over the broken LEFT edge of the phone.
 * The window eats every touch inside it, so ghost touches never reach apps.
 * It follows the screen rotation, so the same physical edge stays covered.
 */
class BlockService : AccessibilityService() {

    private var overlay: View? = null
    private var lastRotation = -1
    private val handler = Handler(Looper.getMainLooper())
    private val renderLater = Runnable { render() }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            render()
            // Check again after the rotation animation is done
            handler.removeCallbacks(renderLater)
            handler.postDelayed(renderLater, 250)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .registerDisplayListener(displayListener, handler)
        render()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        handler.removeCallbacks(renderLater)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .unregisterDisplayListener(displayListener)
        removeOverlay()
        instance = null
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (e: Exception) {
            }
        }
        overlay = null
    }

    private fun render() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) {
            removeOverlay()
            return
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val px = (prefs.getInt("width", 30) * resources.displayMetrics.density).toInt()
        val match = WindowManager.LayoutParams.MATCH_PARENT
        val rotation = (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0

        // When the screen rotates, build the window again (more reliable than resizing it)
        if (rotation != lastRotation) removeOverlay()
        lastRotation = rotation

        // Physical LEFT edge of the phone, for each screen rotation
        val w: Int
        val h: Int
        val g: Int
        when (rotation) {
            Surface.ROTATION_90 -> { w = match; h = px; g = Gravity.BOTTOM or Gravity.LEFT }
            Surface.ROTATION_180 -> { w = px; h = match; g = Gravity.TOP or Gravity.RIGHT }
            Surface.ROTATION_270 -> { w = match; h = px; g = Gravity.TOP or Gravity.LEFT }
            else -> { w = px; h = match; g = Gravity.TOP or Gravity.LEFT }
        }

        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = g
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val color = if (prefs.getBoolean("guide", true)) 0x80FF0000.toInt() else Color.TRANSPARENT

        try {
            val v = overlay
            if (v == null) {
                val nv = View(this)
                nv.setBackgroundColor(color)
                wm.addView(nv, lp)
                overlay = nv
            } else {
                v.setBackgroundColor(color)
                wm.updateViewLayout(v, lp)
            }
        } catch (e: Exception) {
            removeOverlay()
        }
    }

    companion object {
        const val PREFS = "cfg"

        @Volatile
        var instance: BlockService? = null

        fun refresh() {
            instance?.render()
        }
    }
}
