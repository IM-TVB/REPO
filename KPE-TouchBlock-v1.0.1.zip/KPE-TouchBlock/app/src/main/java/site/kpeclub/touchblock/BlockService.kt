package site.kpeclub.touchblock

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Draws a thin invisible window over the broken LEFT edge of the phone.
 * The window eats every touch inside it, so ghost touches never reach apps.
 * It follows the screen rotation, so the same physical edge stays covered.
 */
class BlockService : AccessibilityService() {

    private var overlay: View? = null
    private var lastRotation = -1
    private var lastScreenW = -1
    private var lastScreenH = -1
    private val handler = Handler(Looper.getMainLooper())
    private val renderLater = Runnable { render() }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val (sw, sh) = screenBounds(wm)
            // Games change refresh rate often: only skip when rotation and bounds are unchanged
            if (overlay != null && currentRotation() == lastRotation && sw == lastScreenW && sh == lastScreenH) {
                return
            }
            render()
            // Check again after the rotation or fullscreen transition settles
            handler.removeCallbacks(renderLater)
            handler.postDelayed(renderLater, 250)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .registerDisplayListener(displayListener, handler)
        render()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        render()
        handler.removeCallbacks(renderLater)
        handler.postDelayed(renderLater, 250)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        handler.removeCallbacks(renderLater)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .unregisterDisplayListener(displayListener)
        removeOverlay()
        instance = null
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (e: Exception) {
            }
        }
        overlay = null
    }

    private fun currentRotation(): Int =
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0

    private fun screenBounds(wm: WindowManager): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            WindowManager.LayoutParams.MATCH_PARENT to WindowManager.LayoutParams.MATCH_PARENT
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun render() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) {
            removeOverlay()
            return
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val px = (prefs.getInt("width", 30) * resources.displayMetrics.density).toInt()
        val (screenW, screenH) = screenBounds(wm)
        val rotation = currentRotation()

        // When the screen rotates or bounds change, rebuild the window cleanly
        if (rotation != lastRotation || screenW != lastScreenW || screenH != lastScreenH) {
            removeOverlay()
        }
        lastRotation = rotation
        lastScreenW = screenW
        lastScreenH = screenH

        // Physical LEFT edge of the phone, for each screen rotation
        val w: Int
        val h: Int
        val g: Int
        when (rotation) {
            Surface.ROTATION_90 -> { w = screenW; h = px; g = Gravity.BOTTOM or Gravity.LEFT }
            Surface.ROTATION_180 -> { w = px; h = screenH; g = Gravity.TOP or Gravity.RIGHT }
            Surface.ROTATION_270 -> { w = screenW; h = px; g = Gravity.TOP or Gravity.LEFT }
            else -> { w = px; h = screenH; g = Gravity.TOP or Gravity.LEFT }
        }

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_SPLIT_TOUCH or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (Build.VERSION.SDK_INT < 30) {
            flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        }

        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = g
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 30) {
            lp.fitInsetsTypes = 0
        }
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val color = if (prefs.getBoolean("guide", true)) 0x80FF0000.toInt() else Color.TRANSPARENT

        try {
            val v = overlay
            if (v == null) {
                val nv = View(this).apply {
                    setBackgroundColor(color)
                    setOnTouchListener { _, _ -> true }
                }
                wm.addView(nv, lp)
                overlay = nv
            } else {
                v.setBackgroundColor(color)
                wm.updateViewLayout(v, lp)
            }
        } catch (e: Exception) {
            removeOverlay()
        }
    }

    companion object {
        const val PREFS = "cfg"

        @Volatile
        var instance: BlockService? = null

        fun refresh() {
            instance?.render()
        }
    }
}
